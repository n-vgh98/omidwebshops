@extends('laayoytss.master')

@section('content')

@include('frontend.header')
@include('frontend.slider')
@include('frontend.main')
@include('frontend.footer')

@endsection
